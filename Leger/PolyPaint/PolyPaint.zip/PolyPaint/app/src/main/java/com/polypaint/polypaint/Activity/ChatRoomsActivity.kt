package com.polypaint.polypaint.Activity

import android.app.Activity

class ChatRoomsActivity: Activity(){

}