package com.polypaint.polypaint.Model

class Room (var name: String) {}
