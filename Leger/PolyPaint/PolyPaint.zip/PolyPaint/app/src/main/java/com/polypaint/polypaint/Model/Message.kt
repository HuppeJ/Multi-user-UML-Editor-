package com.polypaint.polypaint.Model

class Message (var text: String, var sender: String, var createdAt: Long) {}
