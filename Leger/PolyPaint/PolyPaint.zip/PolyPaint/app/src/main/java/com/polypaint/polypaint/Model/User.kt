package com.polypaint.polypaint.Model

import android.provider.ContactsContract

class User (var username: String){}
